const nextConfig = {
  transpilePackages: ["@ineqre/db"],
};

export default nextConfig;
